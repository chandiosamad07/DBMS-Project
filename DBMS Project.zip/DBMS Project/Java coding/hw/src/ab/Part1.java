package ab;

import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;  
import java.sql.*;  
public class Part1 extends JFrame implements ActionListener    {
	
	JLabel l1, l2, l3, l4, l5, l6, l7, l8 ,l9,l10,l11,l12,l13,l14,l15; 
	static JTextField tf1, tf2,tf3,tf4, tf5, tf6, tf7,tf8,tf9,tf10,tf11,tf12; 
	  Container container;
	 JButton btn1, btn2;  
	 
	 
	 Part1(){
		 JFrame frame = new JFrame("Part i ORS ");
		 frame.setVisible(true);  
	     frame.setSize(700, 720);  
	    frame.setLayout(null);  
	     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
//	     frame.setTitle("1st part of ORS");  
	     container = getContentPane();
	     l1 = new JLabel("APPLICANT INFORMATION");  
	     l1.setForeground(Color.blue);  
	     l1.setFont(new Font("Serif", Font.BOLD, 20));  
	     l2 = new JLabel("Name");     
	     l3 = new JLabel("Father�s Name");  
	     l4 = new JLabel("Surname");  
	     l5 = new JLabel("Father's Occupation");  
	     l6 = new JLabel("Fathers Mobile");  
	     l7 = new JLabel("Applicant Mobile  ");  
	     l8 = new JLabel("Domicile:\r\n" + "(District)");  
	     l9 = new JLabel("CNIC Card # (Candidate) ");
	     l10 = new JLabel("Date of Brith dd-mm-yy  ");
	     l11 = new JLabel("Email Adress  ");
	     l12 = new JLabel("Province  ");
	     l13=new JLabel("Nationality");
	     l14 = new JLabel("City  ");
	     
	     tf1 = new JTextField();  
	     
	     tf2 = new JTextField();  
	     tf3 = new JTextField();  
	     tf4 = new JTextField();  
	     tf5 = new JTextField();  
	     tf6 = new JTextField();  
	     tf7 = new JTextField();  
	     tf8 = new JTextField();
	     tf9 = new JTextField();
	     tf10 = new JTextField();
	     tf11 = new JTextField();
	     tf12 = new JTextField();
	     btn1 = new JButton("Back");  
	     btn2 = new JButton("Next");  
	     btn1.addActionListener(this);  
	     btn2.addActionListener(this); 
	     
	     l1.setBounds(80, 30, 500, 30);  
	     l2.setBounds(80, 70, 200, 30);  
	     l3.setBounds(80, 110, 200, 30);  
	     l4.setBounds(80, 150, 200, 30);  
	     l5.setBounds(80, 190, 200, 30);  
	     l6.setBounds(80, 230, 200, 30);  
	     
	     l7.setBounds(80, 270, 200, 30);  
	     l8.setBounds(80, 310, 200, 30);  
	     l9.setBounds(80, 350, 200, 30);  
	     l10.setBounds(80, 390, 200, 30);  
	     l11.setBounds(80, 430, 200, 30);  
	     l12.setBounds(80, 470, 200, 30);  
	     l13.setBounds(80, 510, 200, 30);  
	     l14.setBounds(80, 550, 200, 30);  
	     tf1.setBounds(300, 70, 200, 30);  
	     tf2.setBounds(300, 110, 200, 30);  
	     tf3.setBounds(300, 150, 200, 30);  
	     tf4.setBounds(300, 190, 200, 30);  
	     tf5.setBounds(300, 230, 200, 30);
	     tf6.setBounds(300, 270, 200, 30);  
	     tf7.setBounds(300, 310, 200, 30);  
	     tf8.setBounds(300, 350, 200, 30);  
	     tf9.setBounds(300, 390, 200, 30);  
	     tf10.setBounds(300, 430, 200, 30);  
	     tf11.setBounds(300, 470, 200, 30);  
	     tf12.setBounds(300, 510, 200, 30);  
	     
	     btn1.setBounds(150, 590, 100, 30);  
	     btn2.setBounds(260, 590, 100, 30);  
	     
	     
	     
	     frame.add(l1);  
	     frame.add(l2);  
	     frame.add(tf1);  
	     frame.add(l3);  
	     frame.add(tf2);  
	     frame.add(l4);  
	     frame.add(tf3);  
	     frame.add(l5);  
	     frame.add(tf4);  
	     frame.add(l6);  
	     frame.add(tf5);  
	     frame.add(l7);  
	     frame.add(tf6);  
	     frame.add(l8);  
	     frame.add(tf7);  
	     frame.add(l9); 
	     frame.add(tf8);
	     frame.add(l10);
	     frame.add(tf9);
	     frame.add(l11);
	     frame.add(tf10);
	     frame.add(l12);
	     frame.add(tf11);
	     frame.add(l13);
	     frame.add(tf12);
	     frame.add(btn1);  
	     frame.add(btn2);  
	     
//	     frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
//	 	frame.getContentPane().add(btn2);
	    
	     
	    	 btn2.addActionListener(new ActionListener() {
	    	 		public void actionPerformed(ActionEvent ae) {
	    	 			 if (tf1.getText().length()==0)
	    		    	 	 
	    	 		     {
	    	 		    	 JOptionPane.showMessageDialog(null, "please enter your Name ");
	    	 		    	 	 
	    	 		     }
	    	 			 else if (tf2.getText().length()==0)
	    		    	 	 
	    	 		     {
	    	 		    	 JOptionPane.showMessageDialog(null, "please enter your Father Name ");
	    	 		    	 	 
	    	 		     }


	    	 			 else if (tf3.getText().length()==0)
	    		    	 	 
	    	 		     {
	    	 		    	 JOptionPane.showMessageDialog(null, "please enter your SurName ");
	    	 		    	 	 
	    	 		     }
	    	 			 else if (tf4.getText().length()==0)
	    		    	 	 
	    	 		     {
	    	 		    	 JOptionPane.showMessageDialog(null, "please enter your Father's Occupaction ");
	    	 		    	 	 
	    	 		     }
	    	 			else if (tf5.getText().length()!=11)
	    		    	 	 
	    	 		     {
	    	 		    	 JOptionPane.showMessageDialog(null, "please enter Valid Numer of Father ");
	    	 		    	 	 
	    	 		     }
	    	 			 else if (tf6.getText().length()!=11)
	    		    	 	 
	    	 		     {
	    	 		    	 JOptionPane.showMessageDialog(null, "please enter Valid Number of Applicant ");
	    	 		    	 	 
	    	 		     }
	    	 			 else if (tf7.getText().length()==0)
	    		    	 	 
	    	 		     {
	    	 		    	 JOptionPane.showMessageDialog(null, "please enter your Domicile District ");
	    	 		    	 	 
	    	 		     }
	    	 			 
	    	 			 else if (tf8.getText().length()!=13)
	    		    	 	 
	    	 		     {
	    	 		    	 JOptionPane.showMessageDialog(null, "please enter your CNIC");
	    	 		    	 	 
	    	 		     }
	    	 			 else if (tf9.getText().length()==0)
	    		    	 	 
	    	 		     {
	    	 		    	 JOptionPane.showMessageDialog(null, "please enter your Date of Brith ");
	    	 		    	 	 
	    	 		     }
	    	 			 
	    	 			 else if (tf10.getText().length()==0 )
	    		    	 	 
	    	 		     {
	    	 				
	    	 					 JOptionPane.showMessageDialog(null, "please enter Valid Email ");
	    	 					
	    	 					 	 
	    	 		     }
	    	 			 
	    	 			 else if (tf11.getText().length()==0  )
	    		    	 	 
	    	 		     {
	    	 		    	 JOptionPane.showMessageDialog(null, "please enter your Province ");
	    	 		    	 	 
	    	 		     }
	    	 			 else if (tf12.getText().length()==0 )
	    		    	 	 
	    	 		     {
	    	 		    	 JOptionPane.showMessageDialog(null, "please enter your Nationality ");
	    	 		    	 	 
	    	 		     }
	    	 			 
	    	 			 
	    	 			else {
	    	 			frame.dispose();
	    	 			new P2();
	    	 		}
	    	 		 } 
	    	 		});
	    	 
	    

	 	 frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	 	frame.getContentPane().add(btn1);
	 	
	 	btn1.addActionListener(new ActionListener() {
	 		public void actionPerformed(ActionEvent ae) {
	 			frame.dispose();
	 			new LoginForm();
	 		}
	 	});
	 	
	 	//Code for Father Mobile
	 	
	    tf5.addKeyListener(new KeyAdapter() {
	         public void keyPressed(KeyEvent ke) {
	            String value = tf5.getText();
	            int l = value.length();
	            if ((ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9')||ke.getKeyChar() == '\b'){
	               tf5.setEditable(true);
	               l6.setText("Father Mobile");
	               l6.setForeground(Color.black);
	            } else {
	               tf5.setEditable(false);
	               l6.setForeground(Color.red);
	               
	               l6.setText("* Enter only numeric digits(0-9)");
	            }
	         }
	      });
	    //Code for Applicant Mobile 
	    
	    tf6.addKeyListener(new KeyAdapter() {
	         public void keyPressed(KeyEvent ke) {
	            String value = tf6.getText();
	            int l = value.length();
	            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
	               tf6.setEditable(true);
	               l7.setText("Applicant Mobile");
	               l7.setForeground(Color.black);
	            } else {
	               tf6.setEditable(false);
	               l7.setForeground(Color.red);
	               
	               l7.setText("* Enter only numeric digits(0-9)");
	            }
	         }
	      });

	 
	    //Code for CNIC 
	    tf8.addKeyListener(new KeyAdapter() {
	         public void keyPressed(KeyEvent ke) {
	            String value = tf8.getText();
	            int l = value.length();
	            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
	               tf8.setEditable(true);
	               l9.setText("CNIC Card # (Candidate)  ");
	               l9.setForeground(Color.black);
	            } else {
	               tf8.setEditable(false);
	               l9.setForeground(Color.red);
	               
	               l9.setText("* Enter only numeric digits(0-9)");
	            }
	         }
	      });
	    
	    tf9.addKeyListener(new KeyAdapter() {
	         public void keyPressed(KeyEvent ke) {
	            String value = tf9.getText();
	            int l = value.length();
	            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b'||ke.getKeyChar() =='-') {
	               tf9.setEditable(true);
	               l10.setText("Date of Brith dd-mm-yy ");
	               l10.setForeground(Color.black);
	            } else {
	               tf9.setEditable(false);
	               l10.setForeground(Color.red);
	               
	               l10.setText("* Enter only numeric digits(0-9)");
	            }
	         }
	      });
	 }
	  public static void main(String args[])  
	    {  
	        new Part1();  
	    }

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}  
}
