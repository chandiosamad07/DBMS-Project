package ab;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class conn{
    Connection c;
    Statement s;
    String url,uname,pass;
    
    public conn(){  
        try{  
            url="jdbc:mysql://localhost:3306/onlineregister";
           uname= "root";
        	pass="root";
        	//Class.forName("com.mysql.jdbc.Driver");
            
            c = DriverManager.getConnection(url,uname,pass);    
          
             s=c.createStatement();  
       
        
        
        }catch(Exception e){ 
            System.out.println(e);
        }  
   
    
    
    
    
    } 
    
    
    
    
    
}  