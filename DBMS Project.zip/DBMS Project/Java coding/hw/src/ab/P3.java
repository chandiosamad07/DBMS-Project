package ab;

import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;  
import java.sql.*;  
public class P3 extends JFrame implements ActionListener {
	JLabel l1, l2, l3, l4, l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15;
	static JTextField tf1, tf2,tf3,tf4, tf5,tf6, tf7,tf8,tf9,tf10,tf11,tf12; 
	JButton btn1, btn2;  

	P3(){
		JFrame frame = new JFrame("Part iii ORS ");
		frame.setVisible(true);  
		frame.setSize(600, 500);  
		frame.setLayout(null);  
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
	
	     
	     l1 = new JLabel("APPLICANT EDUCATIONAL BACKGROUND");  
	     l1.setForeground(Color.blue);  
	     l1.setFont(new Font("Serif", Font.BOLD, 20));  
	     l2 = new JLabel("Degree");     
	     l3 = new JLabel("Marks\r\n" + "Obtained");  
	     l4 = new JLabel("Total\r\n" + "Marks");  
	     l5 = new JLabel("Percentage");
	     l6 = new JLabel("Primary");  
	     l7 = new JLabel("Matric");  
	     l8 = new JLabel("HSSC-(XI)");  
	     l9 = new JLabel("HSSC-(XII) ");
	     
	     tf1 = new JTextField();  
	     tf2 = new JTextField();  
	     tf3 = new JTextField();  
	     tf4 = new JTextField();  
	     tf5 = new JTextField();  
	     tf6 = new JTextField();  
	     tf7 = new JTextField();  
	     tf8 = new JTextField();
	     tf9 = new JTextField();
	     tf10 = new JTextField();
	     tf11 = new JTextField();
	     tf12 = new JTextField();
	     
	     btn1 = new JButton("Back");  
	     btn2 = new JButton("Next");  
	     btn1.addActionListener(this);  
	     btn2.addActionListener(this); 
	     
	     l1.setBounds(100, 30, 500, 30);  
	     l2.setBounds(110, 70, 200, 30);  
	     l3.setBounds(230, 70, 200, 30);  
	     l4.setBounds(330, 70, 200, 30);  
	     l5.setBounds(430, 70, 200, 30);  
	     l6.setBounds(110, 120, 200, 30);  
	     l7.setBounds(110, 150, 200, 30);  
	     l8.setBounds(110, 180, 200, 30);  
	     l9.setBounds(110, 210, 200, 30);
	     
	     tf1.setBounds(230, 120, 40, 20);  
	     tf2.setBounds(330, 120, 40, 20);  
	     tf3.setBounds(430, 120, 50, 20);  
	     
	     tf4.setBounds(230, 150, 40, 20);  
	     tf5.setBounds(330, 150, 40, 20);  
	     tf6.setBounds(430, 150, 50, 20); 
	     
	     tf7.setBounds(230, 180, 40, 20);  
	     tf8.setBounds(330, 180, 40, 20); 
	     tf9.setBounds(430,180, 50, 20); 
	     
	     tf10.setBounds(230, 210, 40, 20);
	     tf11.setBounds(330, 210, 40, 20);  
	     tf12.setBounds(430, 210, 50, 20);  
	     
	     
	     btn1.setBounds(180, 300, 100, 30);  
	     btn2.setBounds(290, 300, 100, 30);  
	     
	     frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		 	frame.getContentPane().add(btn1);
		 	
		 	btn2.addActionListener(new ActionListener() {
		 		public void actionPerformed(ActionEvent ae) {
   	 			 if (tf1.getText().length()==0)
		    	 	 
	 		     {
	 		    	 JOptionPane.showMessageDialog(null, "please enter Text Feild 1 ");
	 		    	 	 
	 		     }
	 			 else if (tf2.getText().length()==0)
		    	 	 
	 		     {
	 		    	 JOptionPane.showMessageDialog(null, "please enter Text Feild 2 ");
	 		    	 	 
	 		     }


	 			 else if (tf3.getText().length()==0)
		    	 	 
	 		     {
	 		    	 JOptionPane.showMessageDialog(null, "please enter Text Feild 3 ");
	 		    	 	 
	 		     }
	 			 else if (tf4.getText().length()==0)
		    	 	 
	 		     {
	 		    	 JOptionPane.showMessageDialog(null, "please enter enter Text Feild 4 ");
	 		    	 	 
	 		     }
	 			 else if (tf5.getText().length()==0)
		    	 	 
	 		     {
	 		    	 JOptionPane.showMessageDialog(null, "please  enter Text Feild 5 ");
	 		    	 	 
	 		     }
	 			 else if (tf6.getText().length()==0)
		    	 	 
	 		     {
	 		    	 JOptionPane.showMessageDialog(null, "please enter enter Text Feild 6 ");
	 		    	 	 
	 		     }
	 			 else if (tf7.getText().length()==0)
		    	 	 
	 		     {
	 		    	 JOptionPane.showMessageDialog(null, "please enter enter Text Feild 7 ");
	 		    	 	 
	 		     }
	 			 
	 			 else if (tf8.getText().length()==0)
		    	 	 
	 		     {
	 		    	 JOptionPane.showMessageDialog(null, "please enterenter Text Feild 8");
	 		    	 	 
	 		     }
	 			 else if (tf9.getText().length()==0)
		    	 	 
	 		     {
	 		    	 JOptionPane.showMessageDialog(null, "please enter enter Text Feild 9 ");
	 		    	 	 
	 		     }
	 			 
	 			 else if (tf10.getText().length()==0 )
		    	 	 
	 		     {

	 				
	 		    	 JOptionPane.showMessageDialog(null, "please enter  Text Feild 10 ");
	 		    	 	 
	 		     }
	 			 
	 			 else if (tf11.getText().length()==0  )
		    	 	 
	 		     {
	 		    	 JOptionPane.showMessageDialog(null, "please  enter Text Feild 11 ");
	 		    	 	 
	 		     }
	 			 else if (tf12.getText().length()==0 )
		    	 	 
	 		     {
	 		    	 JOptionPane.showMessageDialog(null, "please enter Text Feild 12 ");
	 		    	 	 
	 		     }
	 			 
	 			 
	 			else {
	 				frame.dispose();
		 			new user();
	 		}
		 			
		 		}
		 	});
		 	

		 	 frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		 	frame.getContentPane().add(btn1);
		 	
		 	btn1.addActionListener(new ActionListener() {
		 		public void actionPerformed(ActionEvent ae) {
		 			frame.dispose();
		 			new P2();
		 		}
		 	});
		 	
//		 	Tf1
		 	 tf1.addKeyListener(new KeyAdapter() {
		         public void keyPressed(KeyEvent ke) {
		            String value = tf1.getText();
		            int l = value.length();
		            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
		               tf1.setEditable(true);
		               l6.setText("Primary");
		               l6.setForeground(Color.black);
		            } else {
		               tf1.setEditable(false);
		               l6.setForeground(Color.red);
		               
		               l6.setText("*Enter (0-9)");
		            }
		         }
		      });
//			Tf2
		 	tf2.addKeyListener(new KeyAdapter() {
		         public void keyPressed(KeyEvent ke) {
		            String value = tf2.getText();
		            int l = value.length();
		            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
		               tf2.setEditable(true);
		               l6.setText("Primary");
		               l6.setForeground(Color.black);
		            } else {
		               tf2.setEditable(false);
		               l6.setForeground(Color.red);
		               
		               l6.setText("*Enter (0-9)");
		            }
		         }
		      });
//		 	TF3
		 	tf3.addKeyListener(new KeyAdapter() {
		         public void keyPressed(KeyEvent ke) {
		            String value = tf3.getText();
		            int l = value.length();
		            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
		               tf3.setEditable(true);
		               l6.setText("Primary");
		               l6.setForeground(Color.black);
		            } else {
		               tf3.setEditable(false);
		               l6.setForeground(Color.red);
		               
		               l6.setText("*Enter (0-9)");
		            }
		         }
		      });
		 	
		 	
//		 	Tf4
		 	 tf4.addKeyListener(new KeyAdapter() {
		         public void keyPressed(KeyEvent ke) {
		            String value = tf4.getText();
		            int l = value.length();
		            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
		               tf4.setEditable(true);
		               l7.setText("Matric");
		               l7.setForeground(Color.black);
		            } else {
		               tf4.setEditable(false);
		               l7.setForeground(Color.red);
		               
		               l7.setText("*Enter (0-9)");
		            }
		         }
		      });
//			Tf5
		 	tf5.addKeyListener(new KeyAdapter() {
		         public void keyPressed(KeyEvent ke) {
		            String value = tf5.getText();
		            int l = value.length();
		            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
		               tf5.setEditable(true);
		               l7.setText("Matric");
		               l7.setForeground(Color.black);
		            } else {
		               tf5.setEditable(false);
		               l7.setForeground(Color.red);
		               
		               l7.setText("*Enter (0-9)");
		            }
		         }
		      });
//		 	TF6
		 	tf6.addKeyListener(new KeyAdapter() {
		         public void keyPressed(KeyEvent ke) {
		            String value = tf6.getText();
		            int l = value.length();
		            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
		               tf6.setEditable(true);
		               l7.setText("Matric");
		               l7.setForeground(Color.black);
		            } else {
		               tf6.setEditable(false);
		               l7.setForeground(Color.red);
		               
		               l7.setText("*Enter (0-9)");
		            }
		         }
		      });
		 	
//		 	TF7
		 	tf7.addKeyListener(new KeyAdapter() {
		         public void keyPressed(KeyEvent ke) {
		            String value = tf7.getText();
		            int l = value.length();
		            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
		               tf7.setEditable(true);
		               l8.setText("HSSC-(XI)");
		               l8.setForeground(Color.black);
		            } else {
		               tf7.setEditable(false);
		               l8.setForeground(Color.red);
		               
		               l8.setText("*Enter (0-9)");
		            }
		         }
		      });
		 	
//		 	TF8
		 	tf8.addKeyListener(new KeyAdapter() {
		         public void keyPressed(KeyEvent ke) {
		            String value = tf8.getText();
		            int l = value.length();
		            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
		               tf8.setEditable(true);
		               l8.setText("HSSC-(XI)");
		               l8.setForeground(Color.black);
		            } else {
		               tf8.setEditable(false);
		               l8.setForeground(Color.red);
		               
		               l8.setText("*Enter (0-9)");
		            }
		         }
		      });
		 	
//		 	TF9
		 	tf9.addKeyListener(new KeyAdapter() {
		         public void keyPressed(KeyEvent ke) {
		            String value = tf9.getText();
		            int l = value.length();
		            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
		               tf9.setEditable(true);
		               l8.setText("HSSC-(XI)");
		               l8.setForeground(Color.black);
		            } else {
		               tf9.setEditable(false);
		               l8.setForeground(Color.red);
		               
		               l8.setText("*Enter (0-9)");
		            }
		         }
		      });
		 	
//		 	TF10
		 	tf10.addKeyListener(new KeyAdapter() {
		         public void keyPressed(KeyEvent ke) {
		            String value = tf10.getText();
		            int l = value.length();
		            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
		               tf10.setEditable(true);
		               l9.setText("HSSC-(XII)");
		               l9.setForeground(Color.black);
		            } else {
		               tf10.setEditable(false);
		               l9.setForeground(Color.red);
		               
		               l9.setText("*Enter (0-9)");
		            }
		         }
		      });
		 	
//		 	TF11
		 	tf11.addKeyListener(new KeyAdapter() {
		         public void keyPressed(KeyEvent ke) {
		            String value = tf11.getText();
		            int l = value.length();
		            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
		               tf11.setEditable(true);
		               l9.setText("HSSC-(XII)");
		               l9.setForeground(Color.black);
		            } else {
		               tf11.setEditable(false);
		               l9.setForeground(Color.red);
		               
		               l9.setText("*Enter (0-9)");
		            }
		         }
		      });
//		 	TF12
		 	tf12.addKeyListener(new KeyAdapter() {
		         public void keyPressed(KeyEvent ke) {
		            String value = tf12.getText();
		            int l = value.length();
		            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'||ke.getKeyChar() == '\b') {
		               tf12.setEditable(true);
		               l9.setText("HSSC-(XII)");
		               l9.setForeground(Color.black);
		            } else {
		               tf12.setEditable(false);
		               l9.setForeground(Color.red);
		               
		               l9.setText("*Enter (0-9)");
		            }
		         }
		      });
		 	
	     frame.add(l1);  
	     frame.add(l2);  
	     frame.add(l3);
	     frame.add(l4);
	     frame.add(l5);
	     frame.add(l6);
	     frame.add(l7);
	     frame.add(l8);
	     frame.add(l9);
	     
	     frame.add(tf1);
	     frame.add(tf2);
	     frame.add(tf3);
	     frame.add(tf4);
	     frame.add(tf5);
	     frame.add(tf6);
	     frame.add(tf7);
	     frame.add(tf8);
	     frame.add(tf9);
	     frame.add(tf10);
	     frame.add(tf11);
	     frame.add(tf12);
	     
	     frame.add(btn1);
	     frame.add(btn2);
	     
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	 public static void main(String args[])  
	    {  
	        new P3();  
	    }
}
