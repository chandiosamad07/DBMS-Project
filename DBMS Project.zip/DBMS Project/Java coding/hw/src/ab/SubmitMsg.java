package ab;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class SubmitMsg extends JFrame implements ActionListener{
 JLabel l1;
 
 JButton btn1;
 JButton btn2;
 
 SubmitMsg() {
  JFrame frame = new JFrame("submit ");
  
  l1 = new JLabel("Submit successfully");
  l1.setForeground(Color.BLUE);
  l1.setFont(new Font("Serif", Font.BOLD, 20));

  btn1 = new JButton("Back to Login");
  btn2 = new JButton("Click to Close");

  l1.setBounds(170, 100, 400, 30);
 
  btn1.setBounds(150, 160, 115, 30);
  btn2.setBounds(270, 160, 110, 30);

 
  frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.getContentPane().add(btn1);
	
	btn1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ae) {
			frame.dispose();
			new LoginForm();
		}
	});
	

	     btn2.addActionListener(e -> {
	        frame.dispose();
	     });
	     
  frame.setSize(550, 400);
  frame.setLayout(null);
  frame.setVisible(true);
  
  frame.add(l1);

  frame.add(btn1);
  frame.add(btn2);
  
 }
 

 public static void main(String[] args) {
  new SubmitMsg();
  
 }
@Override
public void actionPerformed(ActionEvent arg0) {
	// TODO Auto-generated method stub
	
}
}
