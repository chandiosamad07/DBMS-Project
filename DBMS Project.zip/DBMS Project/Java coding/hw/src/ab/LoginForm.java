package ab;



import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;



public class LoginForm extends JFrame implements ActionListener{
 JLabel l1, l2, l3;
 JTextField tf1;
 JButton btn1;
 JButton btn2;
 JPasswordField p1;
JFrame a;
ResultSet rs;
String  uname,pass;

 LoginForm() {
  JFrame frame = new JFrame("Welcome to ORS ");
  
  l1 = new JLabel("SIBAU Registration System");
  l1.setForeground(Color.BLUE);
  l1.setFont(new Font("Serif", Font.BOLD, 20));

  l2 = new JLabel("Username");
  l3 = new JLabel("Password");
  tf1 = new JTextField();
  
  p1 = new JPasswordField();
  btn1 = new JButton("Sign in");
  btn2 = new JButton("Sign up");

  l1.setBounds(150, 30, 400, 30);
  l2.setBounds(80, 70, 200, 30);
  l3.setBounds(80, 110, 200, 30);
  tf1.setBounds(150, 70, 200, 30);
  p1.setBounds(150, 110, 200, 30);
  btn1.setBounds(150, 160, 100, 30);
  btn2.setBounds(260, 160, 100, 30);

  frame.add(l1);
  frame.add(l2);
  frame.add(tf1);
  frame.add(l3);
  frame.add(p1);
  frame.add(btn1);
  frame.add(btn2);
  
  
  btn1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ae) {
try {
     	   conn c1 = new conn();
           uname = tf1.getText();
          pass  = p1.getText();
            String q  = " select * from signupform where UserName = '"+uname+"' and password = '"+pass+"'";
          rs = c1.s.executeQuery(q);

            
			
			if (tf1.getText().length()==0)
	    	 	 
		     {
		    	 JOptionPane.showMessageDialog(null, "please enter User Name ");
		    	 	 
		     }
			 else if (p1.getText().length()==0)
	    	 	 
		     {
		    	 JOptionPane.showMessageDialog(null, "please enter your Password");
		    	 	 
		     }
			 else if(tf1.getText().equals("admin")&&p1.getText().equals("admin")) {
			frame.dispose();
			new Admin();
			 }
			
			 
			 else if(rs.next()) {
					frame.dispose();
					new Signin(uname,pass);

			        
			 }
			 else {
				 JOptionPane.showMessageDialog(null, "Please enter a valid Username and Password"); 
			 }
	}catch(Exception e) {
	System.out.println(e);
	}
		}
	});
  
  frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.getContentPane().add(btn2);
	btn2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ae) {
			frame.dispose();
			new Part1();
		}
	});

  frame.setSize(550, 400);
  frame.setLayout(null);
  frame.setVisible(true);
  
 }
 

 public static void main(String[] args) {
  new LoginForm();
  
 }
@Override
public void actionPerformed(ActionEvent arg0) {
	// TODO Auto-generated method stub
	
}
}