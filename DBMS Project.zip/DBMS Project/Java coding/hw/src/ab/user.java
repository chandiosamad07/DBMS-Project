package ab;



import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;



public class user extends JFrame implements ActionListener{
 JLabel l1, l2, l3;
 JTextField tf1;
 JButton btn1;
 JButton btn2;
 JPasswordField p1;
JFrame a;

 user() {
  JFrame frame = new JFrame("Username & Password ");
  
  l1 = new JLabel("User Name & Password");
  l1.setForeground(Color.BLUE);
  l1.setFont(new Font("Serif", Font.BOLD, 20));

  l2 = new JLabel("Username");
  l3 = new JLabel("Password");
  tf1 = new JTextField();
  
  p1 = new JPasswordField();
  btn1 = new JButton("Back");
  btn2 = new JButton("Submit");

  l1.setBounds(150, 30, 400, 30);
  l2.setBounds(80, 70, 200, 30);
  l3.setBounds(80, 110, 200, 30);
  tf1.setBounds(150, 70, 200, 30);
  p1.setBounds(150, 110, 200, 30);
  btn1.setBounds(150, 160, 100, 30);
  btn2.setBounds(260, 160, 100, 30);

  frame.add(l1);
  frame.add(l2);
  frame.add(tf1);
  frame.add(l3);
  frame.add(p1);
  frame.add(btn1);
  frame.add(btn2);
  
 
  btn2.addActionListener(new ActionListener() {
		
	  public void actionPerformed(ActionEvent ae) {
		

			 
		  
		  if (tf1.getText().length()==0)
	    	 	 
		     {
		    	 JOptionPane.showMessageDialog(null, "please enter User Name ");
		    	 	 
		     }
			 else if (p1.getText().length()==0)
	    	 	 
		     {
		    	 JOptionPane.showMessageDialog(null, "please enter  Password");
		    	 	 
		     }
			 else {

			       conn c1 = new conn();
			      

			       
			       	String primary=" "+P3.tf1.getText()+" / "+P3.tf2.getText()+" "+P3.tf3.getText()+"% ";
			       	String matric=" "+P3.tf4.getText()+" / "+P3.tf5.getText()+" "+P3.tf6.getText()+"% ";
			       	String hssci=" "+P3.tf7.getText()+" / "+P3.tf8.getText()+" "+P3.tf9.getText()+"% ";
			    	String hsscii=" "+P3.tf10.getText()+" / "+P3.tf11.getText()+" "+P3.tf12.getText()+"% ";
			
			       
			    	
			       String q1 = "insert into signupform values('"+Part1.tf1.getText()+"','"+Part1.tf2.getText()+"','"+Part1.tf3.getText()+"','"+Part1.tf4.getText()+"','"+Part1.tf5.getText()+"','"+Part1.tf6.getText()+"','"+Part1.tf7.getText()+"','"+Part1.tf8.getText()+"','"+Part1.tf9.getText()+"','"+Part1.tf10.getText()+"','"+Part1.tf11.getText()+"','"+Part1.tf12.getText()+"','"+P2.tf1.getText()+"','"+P2.tf2.getText()+"','"+P2.tf3.getText()+"','"+P2.tf4.getText()+"','"+P2.tf5.getText()+"','"+P2.tf6.getText()+"','"+P2.tf7.getText()+"','"+P2.tf8.getText()+"','"+P2.tf9.getText()+"','"+P2.tf10.getText()+"','"+P2.tf11.getText()+"','"+primary+"','"+matric+"','"+hssci+"','"+hsscii+"','"+tf1.getText()+"', '"+p1.getText()+"'  ) ";  
                  
                   System.out.println(Part1.tf1.getText());
                   try {
					c1.s.executeUpdate(q1);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 
				 
			frame.dispose();
			new SubmitMsg();
			 }
		}
	});
  
  frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	frame.getContentPane().add(btn1);
	btn1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ae) {
			frame.dispose();
			new P3();
		}
	});

  frame.setSize(550, 400);
  frame.setLayout(null);
  frame.setVisible(true);
  
 }
 

 public static void main(String[] args) {
  new user();
  
 }
@Override
public void actionPerformed(ActionEvent arg0) {
	// TODO Auto-generated method stub
	
}
}