-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 12, 2020 at 12:27 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlineregister`
--

-- --------------------------------------------------------

--
-- Table structure for table `signupform`
--
create database onlineregister;
use onlineregister;
DROP TABLE IF EXISTS `signupform`;
CREATE TABLE IF NOT EXISTS `signupform` (
  `name` varchar(200) NOT NULL,
  `FName` varchar(200) NOT NULL,
  `surname` varchar(200) NOT NULL,
  `Foccupation` varchar(200) NOT NULL,
  `FMobile` bigint(200) NOT NULL,
  `Amobile` bigint(200) NOT NULL,
  `district` varchar(200) NOT NULL,
  `cnic` bigint(200) NOT NULL,
  `DoB` varchar(20) NOT NULL,
  `email` varchar(200) NOT NULL,
  `province` varchar(200) NOT NULL,
  `nation` varchar(200) NOT NULL,
  `FStatus` varchar(200) NOT NULL,
  `Gname` varchar(200) NOT NULL,
  `Gmobile` bigint(200) NOT NULL,
  `PAddress` varchar(200) NOT NULL,
  `GCity` varchar(200) NOT NULL,
  `GTahseel` varchar(200) NOT NULL,
  `GDistrict` varchar(200) NOT NULL,
  `GOccupation` varchar(200) NOT NULL,
  `FIncome` int(11) NOT NULL,
  `FMembers` int(11) NOT NULL,
  `FMembersStudying` int(11) NOT NULL,
  `primaryMarks` text NOT NULL,
  `matric` text NOT NULL,
  `hssci` text NOT NULL,
  `hsscii` text NOT NULL,
  `UserName` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signupform`
--



/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
